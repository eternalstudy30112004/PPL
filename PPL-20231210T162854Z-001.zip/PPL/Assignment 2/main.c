#include <stdio.h>
void function(){
    char a[10], b[5];

}
int main()
{
    int a,b,c;
    a = 1;
    b = 5;
    c = 6; 
    function();
    return 0;
}